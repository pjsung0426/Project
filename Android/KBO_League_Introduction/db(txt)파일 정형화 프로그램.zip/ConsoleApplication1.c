﻿#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <string.h>

#define BUF 1024

int main() {
    FILE* readFile = NULL;  //웹에서 긁어온 정보(정형화되지 않은)를 읽을 fd
    FILE* writeFile = NULL;  //정형화한 txt로 쓰기 위한 fd
    char s[100], str[100];   //파일 값을 읽어오고 쓰기 위한 문자열 
    char* context;
    /*파일에서 읽어온 각 정보를 담을 char 포인터*/
    char* date, * club1, * club2, * score1, * score2, * stadium, * ii;

    /*data.txt을 읽기 위해 fileopen*/
    fopen_s(&readFile, "data.txt", "r");
    if (readFile == NULL) return 1
        /*dataDB.txt에 정형화 한 값을 쓰기 위한 fileopen*/;
    fopen_s(&writeFile, "dataDB.txt", "w");
    if (readFile == NULL) return 1;

    /*파일이 끝날 때 까지 읽어오기*/
    while (fgets(s, sizeof(s), readFile)) {
        if (!strcmp(s, "\n")) continue;
        /*fgets로 읽어온 한 줄을 각 인덱스 값마다 “ ” ‘,’로 구분하여 저장
          date = strtok_s(s, " ", &context);
          club1 = strtok_s(NULL, " ", &context);
          score1 = strtok_s(NULL, " ", &context);

         /*만약 경기가 아직 치러지지 않아 score값이 없다면 NULL로 세팅*/
        if (!strcmp(score1, ":")) {
            score1 = "NULL";
            score2 = "NULL";
        }
        /*아니라면 score값을 세팅*/
        else {
            ii = strtok_s(NULL, " ", &context);
            score2 = strtok_s(NULL, " ", &context);
        }
        club2 = strtok_s(NULL, " ", &context);
        stadium = strtok_s(NULL, "\n", &context);
        /*구분한 각 인덱스의 값을 sprintf로 하나의 문자열로 만들기*/
        sprintf_s(str, sizeof(str), "\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\" \n", date, club1, score1, score2, club2, stadium);
        /*dataDB에 wirte*/
        fputs(str, writeFile);
    }

    fclose(readFile);
    fclose(writeFile);
    return 0;
}